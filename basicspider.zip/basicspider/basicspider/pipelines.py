# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
import re, time


class BasicspiderPipeline:

    def open_spider(self, spider):
        self.sfile = open('./key.txt', 'w')

    def close_spider(self, spider):
        self.sfile.close()

    def process_item(self, item, spider):
        html_con = item['bodys']
        hashurl = item['hashurl']
        url = html_con.url
        if not html_con:
            return
        jobs_name = html_con.xpath('//li[@class="relate-job-analysis"]/a/text()').extract_first()
        jobs_name = re.sub(r'\t+|\n+|\s+', '', jobs_name)
        if '专业' not in jobs_name:
            self.sfile.write(jobs_name + '\n')
        self.sfile.flush()
        return item


class BaiduIndexPipeline:

    def open_spider(self, spider):
        spath = '/Users/itxiong/maimai/datacenten/ruofan/index_data/s_url.txt'
        self.sfile = open(spath, 'w+')

    def close_spider(self, spider):
        self.sfile.close()

    def process_item(self, item, spider):
        html = item['bodys']
        html_con = html.body.decode()
        url = html.meta['key']
        bd_url = html.url
        if '抱歉没有' in html_con:
            index = '0'
        elif '脉脉' in html_con:
            index = '1'
        elif 'wappass.baidu.com' in bd_url:
            index = '-1'
        else:
            index = '-2'
        print(url, index)
        self.sfile.write(f'{url}\t{index}\t{bd_url}\n')
        self.sfile.flush()