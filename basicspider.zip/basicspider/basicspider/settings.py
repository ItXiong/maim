# Scrapy settings for basicspider project
#
# For simplicity, this file contains only settings considered important or
# commonly used. You can find more settings consulting the documentation:
#
#     https://docs.scrapy.org/en/latest/topics/settings.html
#     https://docs.scrapy.org/en/latest/topics/downloader-middleware.html
#     https://docs.scrapy.org/en/latest/topics/spider-middleware.html

import random

BOT_NAME = 'basicspider'

SPIDER_MODULES = ['basicspider.spiders']
NEWSPIDER_MODULE = 'basicspider.spiders'


# Crawl responsibly by identifying yourself (and your website) on the user-agent
USER_AGENT_LIST = [
    f"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_1) AppleWebKit/{random.randint(400,600)}.36 (KHTML, like Gecko) Chrome/70.0.{random.randint(100,5000)}.102 Safari/537.45",
    f"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_1) AppleWebKit/{random.randint(100,5000)}.1.15 (KHTML, like Gecko) Version/12.0.1 Safari/{random.randint(100,5000)}.1.15",
    f"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.14; rv:63.0) Gecko/{random.randint(10000000,20000000)} Firefox/{random.randint(32,64)}.0"
]
USER_AGENT = random.choice(USER_AGENT_LIST)

# Obey robots.txt rules
ROBOTSTXT_OBEY = False

# Configure maximum concurrent requests performed by Scrapy (default: 16)
CONCURRENT_REQUESTS = 1

# Configure a delay for requests for the same website (default: 0)
# See https://docs.scrapy.org/en/latest/topics/settings.html#download-delay
# See also autothrottle settings and docs
#DOWNLOAD_DELAY = 3
# The download delay setting will honor only one of:
#CONCURRENT_REQUESTS_PER_DOMAIN = 16
#CONCURRENT_REQUESTS_PER_IP = 16

# Disable cookies (enabled by default)
#COOKIES_ENABLED = False

# Disable Telnet Console (enabled by default)
#TELNETCONSOLE_ENABLED = False

# Override the default request headers:
DEFAULT_REQUEST_HEADERS = {
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'en',
#   'Cookie': 'BIDUPSID=1F4F8CF2B727229D0206ACBE91EFA610; PSTM=1627994487; __yjs_duid=1_ad2ea2829963a5f0836806f98b856fd71639049576117; MAWEBCUID=web_pAErcsESYmVTMmgpbRszapIGTDfhHcOUqBVmGRDJslqQrJjabm; H_WISE_SIDS=107313_110085_127969_179347_184716_188740_189037_189325_189755_190620_191068_191287_191370_192206_193283_194085_194511_194520_195329_195342_195631_196426_196514_197241_197286_197469_197479_197711_197783_198070_198253_199023_199082_199466_199489_199567_199753_200272_200743_200993_201054_201104_201188_201360_201547_201576_201580_201705_201733_201821_201824_201948_201978_201995_202058_202115_202268_202284_202476_202544_202562_202565_202706_202904_202911_202916_203197_203250_203280_203329_203494_203519_203576_203605_203643_203747_204111_204131; BAIDUID=1F4F8CF2B727229DC79402DF905084ED:SL=0:NR=50:FG=1; BD_UPN=123253; BCLID_BFESS=7353350878389124352; BDSFRCVID_BFESS=1xDOJeC626uexOTDq4Y0tKoBoey8chQTH6aoHuhdBuuhuODnDYCpEG0P-U8g0KubpkGrogKK0mOTHv-F_2uxOjjg8UtVJeC6EG0Ptf8g0f5; H_BDCLCKID_SF_BFESS=tbIOoI0btC83qR5gMJ5q-n3HKUrL5t_XbI6y3JjOHJOoDDvKQUrcy4LdjGKJJ47AWRcRs4K-a-bvDpovhUj22lKV3-Aq54Rq0b6PBPJxLCjxSfOg3tjHQfbQ0-RPqP-jW27uanrFfR7JOpkxhfnxyb5DQRPH-Rv92DQMVU52QqcqEIQHQT3m5-5bbN3ht6IHJJAeVILhJCvEqnTmbDTD-tFO5eT22-usa5Tl2hcH0KLKfUcSD5LhQKu0DR6JB-RGaKItXlvVKfb1MRjvyjOdQP0sbhrEKRQzWgFqhp5TtUtWeCnTDMRh-lFuyN3yKMnitIj9-pnKHlQrh459XP68bTkA5bjZKxtq3mkjbPbDfn02eCKuDT_-D5oXDNRf-b-X-DvhsRn-KR3qD4-k-PnVq4tHenQzJURZ5mAqofoXtp60Shbe0tO05MPeLxnJK4jryIonaIQDtbc5JK53jtRMj5JWKhJja5c43bRT3fKy5KJvfj6I3q-VhP-UyN3LWh37btjlMKoaMp78jR093JO4y4Ldj4oxJpOJ5JbMonLafD_MbKKme5_bePut-fPX--RX5ITHQbnq-JK_HnurQtbUXUI8LNDH0MRd2DvZKPD25n6MOn7thnQoQ5tN3bO7ttoyMRRKWp3IKlj4EfcHqtjY3fL1Db0OKjvMtg0J3Jos2f5oepvoD-cc3MkBqtjdJJQOBKQB0KnGbUQkeq8CQft20b0EeMtjW6LEtJ-JVCD-tCP3qn7I5KTO-t4VbfrJ-C62aKDso4ngBhcqEIL4jRoq2M47QhLJX6OJWKOGWb5XfnOsVfbSj4QoybLJb-5t-4vtB2nXKUTn-p5nhMtz3j7JDMP0-l3W0bjy523ion6vQpn-KqQ3DRoWXPIqbN7P-p5Z5mAqKl0MLPbtbb0xb6_0-nDSHH_8J6Lt3f; BDUSS=RVNDlHT1RmdkV4RmVBTWlFSGxpS2stVmRTd3FBbVdhUTVxVHU3elNnN1F4N05pRVFBQUFBJCQAAAAAAAAAAAEAAACs4-Iqx-~1~NLFw84AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANA6jGLQOoxiSD; BDUSS_BFESS=RVNDlHT1RmdkV4RmVBTWlFSGxpS2stVmRTd3FBbVdhUTVxVHU3elNnN1F4N05pRVFBQUFBJCQAAAAAAAAAAAEAAACs4-Iqx-~1~NLFw84AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANA6jGLQOoxiSD; BAIDUID_BFESS=1F4F8CF2B727229DC79402DF905084ED:SL=0:NR=50:FG=1; ZFY=sJJgnPpWg8UWh2OYNDJGSKJuI0kJ2hDFvnXgjPgR:BsE:C; BD_HOME=1; H_PS_PSSID=36425_36554_36464_36594_36454_31660_36453_36165_36073_36519_26350_36467; sug=3; sugstore=0; ORIGIN=0; bdime=0; BA_HECTOR=0la504ag2l8hah2hag1ha3e3614',
    'Host': 'www.baidu.com',
    'Referer': 'https://www.baidu.com/'
}

# Enable or disable spider middlewares
# See https://docs.scrapy.org/en/latest/topics/spider-middleware.html
#SPIDER_MIDDLEWARES = {
#    'basicspider.middlewares.BasicspiderSpiderMiddleware': 543,
#}

# Enable or disable downloader middlewares
# See https://docs.scrapy.org/en/latest/topics/downloader-middleware.html
DOWNLOADER_MIDDLEWARES = {
#    'basicspider.middlewares.BasicspiderDownloaderMiddleware': 543,
#    'basicspider.middlewares.ProxyDownloaderMiddleware': 100,
}

# Enable or disable extensions
# See https://docs.scrapy.org/en/latest/topics/extensions.html
#EXTENSIONS = {
#    'scrapy.extensions.telnet.TelnetConsole': None,
#}

# Configure item pipelines
# See https://docs.scrapy.org/en/latest/topics/item-pipeline.html
ITEM_PIPELINES = {
    'basicspider.pipelines.BaiduIndexPipeline': 300,
}
# USER_AGENT = "Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)"
CONCURRENT_REQUESTS = 1
CONCURRENT_ITEMS = 200
# Enable and configure the AutoThrottle extension (disabled by default)
# See https://docs.scrapy.org/en/latest/topics/autothrottle.html
#AUTOTHROTTLE_ENABLED = True
# The initial download delay
#AUTOTHROTTLE_START_DELAY = 5
# The maximum download delay to be set in case of high latencies
#AUTOTHROTTLE_MAX_DELAY = 60
# The average number of requests Scrapy should be sending in parallel to
# each remote server
#AUTOTHROTTLE_TARGET_CONCURRENCY = 1.0
# Enable showing throttling stats for every response received:
#AUTOTHROTTLE_DEBUG = False

# Enable and configure HTTP caching (disabled by default)
# See https://docs.scrapy.org/en/latest/topics/downloader-middleware.html#httpcache-middleware-settings
#HTTPCACHE_ENABLED = True
#HTTPCACHE_EXPIRATION_SECS = 0
#HTTPCACHE_DIR = 'httpcache'
#HTTPCACHE_IGNORE_HTTP_CODES = []
#HTTPCACHE_STORAGE = 'scrapy.extensions.httpcache.FilesystemCacheStorage'
