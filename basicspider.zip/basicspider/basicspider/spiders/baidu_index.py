from requests import request
import scrapy, urllib, random, time
from scrapy.http import HtmlResponse, Request
from scrapy.spiders import CrawlSpider, Rule
from basicspider.items import BasicspiderItem


class BaiduIndex(scrapy.Spider):
    name = 'baidu_index'
    rfile = '/Users/itxiong/Downloads/baiduinclude/sample_uri.txt'
    url = [x.strip() for x in open(rfile)]

    def start_requests(self):
        for yy in self.url:
            rsv_pq = ''
            aa = f"ie=utf-8&f=8&rsv_bp=1&tn=baidu&rsv_pq=8a{random.randint(100,999)}0f7{random.randint(100,999)}24bcc&rsv_t=44KgfGGoonQWylbrSFEbnqox2MkFETtzl{random.randint(100,999)}jhij5VZhgSWdRdDBDI9eMI"
            y = urllib.parse.quote_plus(yy)
            url=f'http://www.baidu.com/s?wd={y}&{aa}&rn=10'
            # time.sleep(0.5)
            yield scrapy.Request(url=url,callback=self.parse, meta={'key': yy})

    def parse(self, response):
        item = BasicspiderItem()
        item['bodys'] = response
        bd_response = response.url
        if 'wappass.baidu.com' in bd_response:
            time.sleep(15)
        yield item
