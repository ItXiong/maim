import hashlib
from scrapy.http import HtmlResponse, Request
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
from bloom_filter import BloomFilter
from basicspider.items import LiepinJobs

class Liepin(CrawlSpider):
    name = 'liepinjobs'
    bloom_requests_urls = BloomFilter(max_elements=100000, error_rate=0.1)
    start_urls = ['https://www.jobui.com/gangwei/waimaoyewuyuanwaimaozhuanyuan/']
    rules = (Rule(
        LinkExtractor(
            allow_domains='www.jobui.com', deny_domains=(r'[^w].jobui.com',), allow=(r'/gangwei/[a-z0-9]+/$')
        ), callback='parse_item', follow=True
    ), )

    def _requests_to_follow(self, response):
        if not isinstance(response, HtmlResponse):
            return
        seen = set()
        for rule_index, rule in enumerate(self._rules):
            links = [lnk for lnk in rule.link_extractor.extract_links(response)
                     if lnk not in seen]
            for link in rule.process_links(links):
                url = link.url
                dumd5 = hashlib.md5(url.encode()).hexdigest()
                if dumd5 not in self.bloom_requests_urls:
                    seen.add(link)
                    self.bloom_requests_urls.add(dumd5)
                    request = self._build_request(rule_index, link, dumd5)
                    yield rule.process_request(request, response)

    def _build_request(self, rule_index, link, dumd5):
        return Request(
            url=link.url,
            callback=self._callback,
            errback=self._errback,
            meta=dict(rule=rule_index, link_text=link.text, hashurl=dumd5),
        )

    def parse_item(self, response):
        ltitem = LiepinJobs()
        ltitem['hashurl'] = response.meta['hashurl']
        ltitem['bodys'] = response
        yield ltitem